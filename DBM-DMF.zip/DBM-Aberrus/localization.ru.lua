if GetLocale() ~= "ruRU" then return end
local L

---------------------------
--  Kazzara --
---------------------------
--L= DBM:GetModLocalization(2522)

--L:SetWarningLocalization({
--})
--
--L:SetTimerLocalization{
--}
--
--L:SetOptionLocalization({
--})
--
--L:SetMiscLocalization({
--})

---------------------------
--  Molgoth --
---------------------------
--L= DBM:GetModLocalization(2529)

---------------------------
--  Experimentation of the Dracthyr --
---------------------------
--L= DBM:GetModLocalization(2530)

---------------------------
--  Zaqali Invasion/ Djaradin Assault --
---------------------------
--L= DBM:GetModLocalization(2524)

---------------------------
--  Rashok --
---------------------------
--L= DBM:GetModLocalization(2525)

---------------------------
--  Zskarn --
---------------------------
--L= DBM:GetModLocalization(2532)

---------------------------
--  Magmorax --
---------------------------
--L= DBM:GetModLocalization(2527)

---------------------------
--  Echo of Neltharion --
---------------------------
--L= DBM:GetModLocalization(2523)

---------------------------
--  Scalecommander Sarkareth --
---------------------------
--L= DBM:GetModLocalization(2520)

-------------
--  Trash  --
-------------
L = DBM:GetModLocalization("AberrusTrash")

L:SetGeneralLocalization({
	name =	"Трэш мобы Аберрий, Затененное Горнило"
})
